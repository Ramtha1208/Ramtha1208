<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Welcome extends CI_Controller {

	
	public function index()
	{
		error_reporting(E_ALL);
ini_set('display_errors', 0);
		//phpinfo();
		$this->ViewData();
	}

	public function ViewData()
	{

		if ($this->input->is_ajax_request()) {
			$limit = $this->input->post('limit_records') ?? 10;
			$url =  'http://phpstack-775269-2637198.cloudwaysapps.com/sandbox/1bx/partnerapi/partner/getMatches?limit='.$limit.'&page=1';
		} else {
			$url =  'http://phpstack-775269-2637198.cloudwaysapps.com/sandbox/1bx/partnerapi/partner/getMatches';
		}
			$curl = curl_init();
			curl_setopt_array($curl, array(
			CURLOPT_URL => $url,
			CURLOPT_RETURNTRANSFER => true,
			CURLOPT_ENCODING => '',
			CURLOPT_MAXREDIRS => 10,
			CURLOPT_TIMEOUT => 0,
			CURLOPT_FOLLOWLOCATION => true,
			CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
			CURLOPT_CUSTOMREQUEST => 'GET',
			CURLOPT_HTTPHEADER => array(
			'apiKey:  7piqdyfeHgWOHUp',
			'authorization:  Bearer 8db2d11c160a1d0633ffcc88fddcaa49a9cc3636590c611de9d16ed8864c74a212'
			),
			));

			$response = curl_exec($curl);

			curl_close($curl);
			
			$data['result'] = json_decode($response,true);

		$this->load->view('viewdata',$data);
	}

	public function getApiData()
	{

	}
}
