<!DOCTYPE html>
<html>
<title> View Table Data </title>
<head>
<link rel = "stylesheet" href = "https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
<script src = "https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js">
        </script>
<script src = "https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js">
</script>
<script src = "https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js">
</script>
<link rel = "stylesheet" href = "https://cdn.datatables.net/1.10.21/css/dataTables.bootstrap4.min.css">
<script src = "https://cdn.datatables.net/1.10.21/js/jquery.dataTables.min.js">
</script>
<script src = "https://cdn.datatables.net/1.10.21/js/dataTables.bootstrap4.min.js">
</script>
<script>
$(document).ready(function() {
$('#myTable').DataTable();
} );
</script>

<style>
table, tr, td{
 border:none;
}
table {
    width:100%;
}
    </style>
</head>
<body>
    <div style="width:100%;" id="table_data">
    <table class="table table-bordered table-dark">
        <tr>
         <th style="text-align:right"> Please Enter No of Records To Display </th>
         <th> : </th>   
        <th> <input type="number" class="form-control" name="no_record" placeholder="no of records" min="1"  id="limit_records" /> </th>
        <th> <input type="button" class="btn btn-primary btn-sm" name="Search" value="Search" onclick="SearchFromData()"/> </th>
        </tr>
    </table>
  
      

<table id = "myTable" class = "table table-bordered" style = "width: 100%">
<thead>
<tr>
    <th> Match id </th>
    <th> Match name </th>
    <th> Match Date </th>
    <th> Event Type </th>
    <th> Team Name A </th>
    <th> Team Name B </th>
    <th> Tournament  </th>
    <th> Stadium </th>
    <th> Country </th>
    <th> City </th>
    <th> Price </th>
</tr>
</thead>
<tbody>
        <?php 

        $status_code = $result['status'];
        if($status_code != 1){
        echo "<tr> <th colspan='11'> No Data Found! </tr>";
        } else {
        foreach($result['result'] as $resutdata)
        {

        ?>
    <tr>
    <td> <?php echo $resutdata['match_id'] ?> </td>
    <td> <?php echo $resutdata['match_name'] ?></td>
    <td> <?php echo $resutdata['match_date'] ?></td>
    <td> <?php echo $resutdata['event_type'] ?></td>
    <td> <img src="<?php echo $resutdata['team_image_a'] ?>" title="<?php echo $resutdata['team_name_a'] ?>" style="width:70px"/></td>
    <td> <img src="<?php echo $resutdata['team_image_b'] ?>" title="<?php echo $resutdata['team_image_b'] ?>" style="width:70px"/></td>
    <td> <?php echo $resutdata['tournament_name'] ?></td>
    <td> <?php echo $resutdata['stadium_name'] ?></td>
    <td> <?php echo $resutdata['country_name'] ?></td>
    <td> <?php echo $resutdata['city_name'] ?></td>
    <td>  <?php echo $resutdata['price_witd_symbol'] ?> </td>
    </tr>
    <?php
    }   
    }
    ?>
</table>

 </div>
 <script>
    function SearchFromData() {
        
         var limit_records = $('#limit_records').val();
         if(limit_records <= 0){
            alert('No of records more than zero');
            return false;
         }
         var json_obj = "";
            jQuery.ajax({
            type: "POST",
            url: '?c=Welcome&m=ViewData',
            dataType: 'html',
            async: false,
            data: {limit_records: limit_records},
            success: function(res) 
            {
                $("#table_data").html(res);
            },
            error:function()
            {
            alert('Something Went Wrong');
            return false;	
            }
            }); 

            
    }
</script>  
</body>
</html>